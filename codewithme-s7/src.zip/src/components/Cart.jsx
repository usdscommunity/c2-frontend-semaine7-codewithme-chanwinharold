
function Cart() {
    return (
        <div>
            Panier
        </div>
    );
}

export default Cart;